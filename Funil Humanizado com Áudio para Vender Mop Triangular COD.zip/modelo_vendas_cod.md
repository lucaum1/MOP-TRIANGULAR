## Modelo de Vendas COD (Cash on Delivery)

O modelo principal de vendas é o Cash on Delivery (COD), onde o cliente paga na entrega. Caso o cliente não esteja em localizações atendidas por este método, tenta-se convencê-lo a pagar pelo método tradicional. Se ainda assim não aceitar, o Pay After Delivery (PAD) é acionado.

**Percentuais de uso:**
- 80% COD
- 15% ANTECIPADOS
- 5% PAD


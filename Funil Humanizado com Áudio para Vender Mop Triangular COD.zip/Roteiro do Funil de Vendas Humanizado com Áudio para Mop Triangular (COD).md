# Roteiro do Funil de Vendas Humanizado com Áudio para Mop Triangular (COD)

Este roteiro detalha as etapas do funil de vendas, com foco na interação humanizada através de áudios, utilizando o modelo de pagamento na entrega (COD) para o produto Mop Triangular.

## 1. Mensagem de Boas-Vindas (Áudio Inicial)

**Objetivo:** Captar a atenção do cliente, apresentar o Mop Triangular de forma intrigante e convincente, e introduzir o conceito de pagamento na entrega para gerar confiança e engajamento.

**Conteúdo do Áudio:**

"Olá! Que bom ter você aqui! Eu sou [Nome do Agente/Marca], e tenho uma pergunta rápida para você: Você já se cansou de gastar horas limpando o chão, se curvando e torcendo panos sujos? E se eu te dissesse que existe uma solução que pode transformar a sua rotina de limpeza, tornando-a mais rápida, fácil e eficiente, sem que você precise pagar nada agora? Sim, é isso mesmo! Estamos falando do revolucionário Mop Triangular, e você só paga quando ele chegar na sua casa e você puder ver a mágica acontecer. Para começarmos, me diga: Qual é o seu maior desafio na hora de limpar a casa hoje?"



## 2. Áudio de Qualificação/Interesse

**Objetivo:** Aprofundar o engajamento do cliente com base na resposta ao áudio inicial, apresentando os benefícios do Mop Triangular de forma personalizada e reforçando a segurança do modelo COD.

**Conteúdo do Áudio (Exemplo - se o cliente mencionar dificuldade com cantos e sujeira difícil):**

"Entendi perfeitamente! Muitas pessoas enfrentam essa dificuldade com os cantos e aquela sujeira que parece nunca sair. É exatamente aí que o Mop Triangular se destaca! Seu design inovador alcança cada cantinho, e a microfibra de alta absorção remove a sujeira mais incrustada com uma única passada. E o melhor: você não precisa se preocupar em esfregar ou se abaixar. Ele faz todo o trabalho pesado por você. Pensando nisso, qual dessas características te atraiu mais: a facilidade de alcançar cantos ou a eficiência na remoção de sujeira?"



## 3. Áudio de Quebra de Objeções/Benefícios

**Objetivo:** Abordar possíveis objeções ou dúvidas do cliente, reforçando os benefícios do Mop Triangular e a segurança da compra com o modelo COD.

**Conteúdo do Áudio (Exemplo - se o cliente demonstrar interesse na eficiência, mas tiver dúvidas sobre a durabilidade ou uso):**

"Que ótimo que a eficiência te chamou a atenção! E sobre a durabilidade, pode ficar tranquilo(a)! O Mop Triangular é feito com materiais de alta qualidade, pensado para durar muito tempo e resistir ao uso diário. A microfibra é lavável e reutilizável, o que o torna super econômico e sustentável. Além disso, a facilidade de uso é impressionante: é só molhar, torcer no próprio balde (sem contato com a água suja!) e pronto para usar. E lembre-se, você só paga quando receber o Mop em casa, testar e comprovar tudo isso. Você gostaria de saber mais sobre como ele funciona na prática ou sobre as vantagens de não precisar pagar nada agora?"



## 4. Áudio de Chamada para Ação/Fechamento

**Objetivo:** Guiar o cliente para a decisão de compra, oferecendo um caminho claro para adquirir o Mop Triangular com a segurança do pagamento na entrega.

**Conteúdo do Áudio (Exemplo - se o cliente demonstrar interesse em como funciona na prática ou nas vantagens do COD):**

"Perfeito! Para você ver como o Mop Triangular funciona na prática e experimentar todas as vantagens de uma limpeza sem esforço, eu tenho uma proposta irrecusável. Que tal receber o seu Mop Triangular diretamente na sua casa, sem custo de envio e sem precisar pagar nada agora? Você só faz o pagamento quando o produto chegar e você puder testar e comprovar a sua eficácia. Para garantir o seu, basta me confirmar o seu nome completo e endereço de entrega. Posso prosseguir com o seu pedido?"


# Manual de Uso - Funil de Vendas Mop Triangular

## Como Usar o Funil

### 1. Hospedagem
Para usar o funil, você pode:
- Hospedar os arquivos em qualquer servidor web
- Usar serviços como Netlify, Vercel ou GitHub Pages
- Colocar em seu próprio servidor

### 2. Estrutura dos Arquivos
```
funil-vendas-mop/
├── index.html          # Página principal
├── styles.css          # Estilos visuais
├── script.js           # Funcionalidades JavaScript
└── audio_funil/        # Pasta com os áudios
    ├── boas_vindas.wav
    ├── qualificacao_interesse.wav
    ├── quebra_objecoes_beneficios.wav
    └── chamada_acao_fechamento.wav
```

### 3. Personalização

#### Alterando Textos
- Edite o arquivo `index.html` para modificar textos
- Mantenha a estrutura HTML para preservar a funcionalidade

#### Modificando Cores
- Edite o arquivo `styles.css`
- As cores principais estão definidas nos gradientes

#### Substituindo Áudios
- Substitua os arquivos na pasta `audio_funil/`
- Mantenha os mesmos nomes de arquivo
- Use formato WAV para melhor compatibilidade

### 4. Integrações Possíveis

#### Analytics
- Adicione Google Analytics no `<head>` do HTML
- O JavaScript já possui eventos trackEvent() prontos

#### CRM/Email Marketing
- Modifique a função `processarPedido()` no script.js
- Integre com APIs de CRM como RD Station, HubSpot, etc.

#### WhatsApp
- Configure o número no final da página de confirmação
- Adicione botão de WhatsApp se desejar

### 5. Otimizações de Conversão

#### A/B Testing
- Teste diferentes versões da mensagem de boas-vindas
- Varie as opções de resposta
- Experimente diferentes preços

#### Melhorias Sugeridas
- Adicionar depoimentos de clientes
- Incluir fotos reais do produto
- Criar senso de urgência (oferta limitada)
- Adicionar garantia de satisfação

### 6. Monitoramento
- Acompanhe as taxas de conversão por etapa
- Identifique onde os usuários mais abandonam
- Otimize os pontos de maior abandono

